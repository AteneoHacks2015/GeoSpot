/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.webservice.services;

import com.mycompany.webservice.model.Person;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Application;  

/**
 *
 * @author Ian
 */
@Path("service")
public class Service extends Application {
    
    //private final HashMap<String, Person> users = new HashMap<>();
    private static final Map<String, Person>  users = new HashMap<String,Person>();
    
    @GET
    @Path("/checkUsernameAvailability/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public String checkUsernameAvailability(@PathParam("id")String id){
        if(users.containsKey(id))
            return "taken";
        else return "availlable";
       
    }
    
    @GET
    @Path("/checkPassword/{id}/{pass}")
    @Produces(MediaType.APPLICATION_JSON)
    public String checkPassword(@PathParam("id")String id,@PathParam("pass") String pass){
        if(pass.equals(users.get(id).getReview()))
            return "yes";
        else return "no";
        
        
    }
    
    @GET
    @Path("/getPoints/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public String getPoints(@PathParam("id") String id){
        return Integer.toString(users.get(id).getPoints());
       
    }
    
    @GET
    @Path("/getAccuracy/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public String getAccuracy(@PathParam("id") String id){
        return Integer.toString(users.get(id).getAccuracy());
       
    }
    
    @GET
    @Path("/getCorrect/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public String getCorrect(@PathParam("id") String id){
        return Integer.toString(users.get(id).getCorrect());
       
    }
    
    @GET
    @Path("/getWrong/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public String getWrong(@PathParam("id") String id){
        return Integer.toString(users.get(id).getWrong());
       
    }
    
    @GET
    @Path("/getHighScores")
    @Produces(MediaType.APPLICATION_XML)
    public Person[] getHighScores(){
        Person [] pArray = new Person[users.size()];
        int i = 0;
        for (Object value : users.values()) {
            pArray[i] = (Person) value;
        }
        
        return pArray;
       
    }
    
   
    
    
    @GET
    @Path("/saveUser/{id}/{review}/{rating}")
    @Produces(MediaType.APPLICATION_JSON)
    public String saveUser(@PathParam("id") String id, @PathParam("review") String review, @PathParam("rating") String rating){
                int point = Integer.parseInt(rating);
                System.out.println("id is " + id + ", name is " + id + ", review is " + point);
                Person newPer = new Person(id, review, point);  
                users.put(id, newPer);
                
            System.out.println(users.get(id).getName());
            System.out.println(users.get(id).getReview());
            System.out.println(Integer.toString(users.get(id).getPoints()));
                
            if(users.containsKey(id))
                return "ok";    
            return "failed to save";
    }
    
    
    @GET
    @Path("/addPoints/{id}/{points}")
    @Produces(MediaType.APPLICATION_JSON)
    public void addPoints(@PathParam("id")String id, @PathParam("points") String points){
        int currentPoint = users.get(id).getPoints();
        int addPoint = Integer.parseInt(points);
        currentPoint += addPoint; 
        users.get(id).setPoints(currentPoint);
       
    }
    
    @GET
    @Path("/addQuiz/{id}/{points}")
    @Produces(MediaType.APPLICATION_JSON)
    public void addQuiz(@PathParam("id")String id, @PathParam("points") String points){
        int currentPoint = users.get(id).getPoints();
        int addPoint = Integer.parseInt(points);
        currentPoint += addPoint; 
        users.get(id).setPoints(currentPoint);
       
    }
}