/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.webservice.model;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 *
 * @author Ian
 */
@XmlRootElement(name = "person")
@XmlType(propOrder={"name", "review", "rating"})
public class Person {
    private String name;
    private String rev;
    private int points;
    private int correct;
    private int wrong;

    public Person (String n, String r, int rat){
        name = n;
        rev = r;
        points = rat;
    }
    
    public Person (){
       
    }
    
    @XmlElement
    public int getPoints(){
        return points;
    }
    
    @XmlElement
    public int getCorrect(){
        return correct;
    }
    
    @XmlElement
    public int getWrong(){
        
        return wrong;
    }
    
    @XmlElement
    public int getAccuracy(){
        if(correct != 0 && wrong != 0)
            return correct /= (correct + wrong);
        return 0;
    }
    
    @XmlElement
    public int getTotal(){
        return wrong + correct;
    }
    
    
    public void setPoints(int rat){
        this.points = rat;
    }
    
    @XmlElement
    public String getName(){
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    @XmlElement
    public String getReview() {
        return rev;
    }

    public void setReview(String review) {
        this.rev = review;
    }
    
    
    
}
